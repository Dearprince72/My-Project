const recordForm = document.getElementById('record-form');
const nameInput = document.getElementById('name');
const ageInput = document.getElementById('age');
const emailInput = document.getElementById('email');
const recordList = document.getElementById('record-list');
const editIndexInput = document.getElementById('edit-index');

let records = JSON.parse(localStorage.getItem('records')) || [];

function isDuplicateEmail(email) {
  return records.some((record, index) => 
    record.email.toLowerCase() === email.toLowerCase() &&
    index !== parseInt(editIndexInput.value)
  );
}

function displayRecords() {
  recordList.innerHTML = '';
  if (records.length === 0) {
    const row = document.createElement('tr');
    row.innerHTML = `<td colspan="5" style="text-align:center;color:red">No Record Found</td>`;
    recordList.appendChild(row);
  } else {
    records.forEach((record, index) => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${record.name}</td>
        <td>${record.age}</td>
        <td>${record.email}</td>
        <td><button onclick="editRecord(${index})">Edit</button></td>
        <td class="deleteButton">
          <button onclick="promptDelete(${index})">Delete</button>
        </td>`;
      recordList.appendChild(row);
    });
  }
}

recordForm.addEventListener('submit', function (e) {
  e.preventDefault();
  const name = nameInput.value.trim();
  const age = ageInput.value.trim();
  const email = emailInput.value.trim();
  const editIndex = parseInt(editIndexInput.value);

  if (name && age && email) {
    if (isDuplicateEmail(email) && editIndex === -1) {
      alert('Email already exists.');
      return;
    }

    const record = { name, age, email };
    if (editIndex === -1) {
      records.push(record);
    } else {
      records[editIndex] = record;
      editIndexInput.value = -1;
    }

    localStorage.setItem('records', JSON.stringify(records));
    nameInput.value = '';
    ageInput.value = '';
    emailInput.value = '';
    displayRecords();
  }
});

function editRecord(index) {
  const record = records[index];
  nameInput.value = record.name;
  ageInput.value = record.age;
  emailInput.value = record.email;
  editIndexInput.value = index;
}

function promptDelete(index) {
  const deleteCell = document.querySelectorAll('.deleteButton')[index];
  deleteCell.innerHTML = `
    <i id="yesBtn" class="fa-solid fa-check" onclick="confirmDelete(${index})"></i>
    <i id="noBtn" class="fa-solid fa-xmark" onclick="displayRecords()"></i>
  `;
}

function confirmDelete(index) {
  records.splice(index, 1);
  localStorage.setItem('records', JSON.stringify(records));
  displayRecords();
}

// Initial display
displayRecords();
